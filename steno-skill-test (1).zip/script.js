function calculateAccuracy(original, typed) {
  const originalWords = original.trim().split(/\s+/);
  const typedWords = typed.trim().split(/\s+/);
  let correct = 0;

  for (let i = 0; i < originalWords.length; i++) {
    if (typedWords[i] === originalWords[i]) {
      correct++;
    }
  }

  return ((correct / originalWords.length) * 100).toFixed(2);
}